jQuery.soap Description of Classes
==================================
**file:** jquery.soap.js  
**version:** 1.4.2

This document is giving an overview of the classes used within $.soap. 

##_WORK IN PROGRESS_

new SOAPObject(name)
--------------------
attributes  
children  
name  
ns  
_parent  
value  
typeOf = 'SOAPObject'  

###**methods:**

#####addNamespace(name, url)

#####addParameter(name, value)

#####appendChild(soapObject)

#####attr(name, value)

#####end()

#####find(name)

#####hasChildren()

#####newChild(name)

#####parent()

#####toString()

#####val(value)



new SOAPEnvelope(soapObject)
============================
**constructor:** `new SOAPEnvelope(soapObject);`

**properties:**